//
//  BasicNavigationController.m
//  ShangJiaLM
//
//  Created by shese on 2017/10/31.
//  Copyright © 2017年 baipeng. All rights reserved.
//

#import "BasicNavigationController.h"
#import "UIBarButtonItem+Extension.h"

@interface BasicNavigationController ()

@end

@implementation BasicNavigationController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.navigationBar.translucent = NO;
    // Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

+ (void)initialize
{
    //设置navigationBar样式
    [self setupNavigationBarTheme];
    //设置barButtonItem样式
    [self setupBarButtonItemTheme];
}
/*
*  设置navigationBar标题样式
*/
+ (void)setupNavigationBarTheme
{
    UINavigationBar *appearance = [UINavigationBar appearance];
    NSMutableDictionary *textAttrs = [NSMutableDictionary dictionary];
    textAttrs[NSForegroundColorAttributeName] = [UIColor whiteColor];
    //textAttrs[NSFontAttributeName] = kNavigationBarTitleFont;
    [appearance setTitleTextAttributes:textAttrs];
    [appearance setTintColor:[UIColor whiteColor]];

}

/**
 *  设置barButtonItem
 */
+ (void)setupBarButtonItemTheme
{
    UIBarButtonItem *appearance = [UIBarButtonItem appearance];
    NSMutableDictionary *textAttrs = [NSMutableDictionary dictionary];
    textAttrs[NSForegroundColorAttributeName] = [UIColor whiteColor];
    //textAttrs[NSFontAttributeName] = kBarButtonItemFont;
    [appearance setTitleTextAttributes:textAttrs forState:UIControlStateNormal];

    appearance.tintColor=[UIColor whiteColor];

}




@end
