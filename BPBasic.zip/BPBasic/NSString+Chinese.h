//
//  NSString+Chinese.h
//  BPAlertViewDemo
//
//  Created by BP on 2017/11/20.
//  Copyright © 2017年 baipeng. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSString (Chinese)

-(BOOL)isChinese;

-(BOOL)includeChinese;

@end
