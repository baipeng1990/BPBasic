//
//  BasicViewController.h
//  ShangJiaLM
//
//  Created by shese on 2017/10/31.
//  Copyright © 2017年 baipeng. All rights reserved.
//

#import <UIKit/UIKit.h>

#define SCREEN_WIDTH   [UIScreen mainScreen].bounds.size.width
#define SCREENH_HEIGHT [UIScreen mainScreen].bounds.size.height
#define RGBA(r,g,b,a) [UIColor colorWithRed:(r)/255.0 green:(g)/255.0 blue:(b)/255.0 alpha:(a)]
#define RGB(r,g,b) [UIColor colorWithRed:(r)/255.0 green:(g)/255.0 blue:(b)/255.0 alpha:1]
#define MAIN_COLOR RGBA(245, 81, 30, 1)

#define ISIOS11 [UIDevice currentDevice].systemVersion .doubleValue>=11?YES:NO

#define COVERCOLOR RGBA(221, 221,221,0.7)


@interface BasicViewController : UIViewController

@end
