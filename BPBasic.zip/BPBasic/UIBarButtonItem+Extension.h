//
//  UIBarButtonItem+Extension.h
//  WEIBO
//
//  Created by FangZhaohui on 15/4/16.
//  Copyright (c) 2015年 lvbh. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIBarButtonItem (Extension)

+(UIBarButtonItem *)itemWithImageName:(NSString *)imageName highlightImageName:(NSString *)highlightImageName target:(id)target action:(SEL)action;
+(UIBarButtonItem *)itemWithTitle:(NSString *)buttouTitle target:(id)target action:(SEL)action;
@end
