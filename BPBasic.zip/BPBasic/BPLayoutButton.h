//
//  BPLayoutButton.h
//  BPLayoutButton
//
//  Created by shese on 2017/7/24.
//  Copyright © 2017年 baipeng. All rights reserved.
//

#import <UIKit/UIKit.h>

typedef NS_ENUM(NSInteger , BPLayoutButtonStyle){
    BPLayoutButtonStyleLeftImageRightTitle,
    BPLayoutButtonStyleLeftTitleRightImage,
    BPLayoutButtonStyleUpImageDownTitle,
    BPLayoutButtonStyleUpTitleDownImage,
} ;

@interface BPLayoutButton : UIButton

//  样式
@property (nonatomic,assign) BPLayoutButtonStyle layoutStyle;
/// 图片和文字的间距，默认值8
@property (nonatomic, assign) CGFloat midSpacing;
/// 指定图片size
@property (nonatomic, assign) CGSize imageSize;


@end
