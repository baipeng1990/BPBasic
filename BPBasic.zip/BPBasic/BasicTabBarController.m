//
//  BasicTabBarController.m
//  ShangJiaLM
//
//  Created by shese on 2017/10/31.
//  Copyright © 2017年 baipeng. All rights reserved.
//

#import "BasicTabBarController.h"
#import "HomePageViewController.h"
#import "ClassifyViewController.h"
#import "BusinessCenterViewController.h"
#import "FindViewController.h"
#import "PersonalViewController.h"
#import "BasicNavigationController.h"

#define k_unselectedImage   @"unselectedImage"
#define k_selectedImage     @"selectedImage"
#define rgb(a,b,c)      [UIColor colorWithRed:a/255.0f green:b/255.0f blue:c/255.0f alpha:1.0f]
#define TAB_BAR_ITEM_TITLE_NORMAL_COLOR     rgb(102,102,102) //tab正常状态下字体颜色
#define TAB_BAR_ITEM_TITLE_SELECTED_COLOR   rgb(225,93,51)   //tab点击后的字体颜色

@interface BasicTabBarController ()

@end

@implementation BasicTabBarController

+ (void)load
{
    [[UITabBarItem appearance] setTitleTextAttributes:@{NSForegroundColorAttributeName : TAB_BAR_ITEM_TITLE_NORMAL_COLOR} forState:UIControlStateNormal];
    [[UITabBarItem appearance] setTitleTextAttributes:@{NSForegroundColorAttributeName : TAB_BAR_ITEM_TITLE_SELECTED_COLOR} forState:UIControlStateSelected];
    [[UITabBarItem appearance]setTitlePositionAdjustment:UIOffsetMake(0, -3)];
}

- (void)viewDidLoad {
    [super viewDidLoad];
    
    [self.view setBackgroundColor:[UIColor whiteColor]];
    
    [self showtabbar];
}

- (void)changeTabBarItemStyle
{
    
}

-(void)showtabbar
{
    HomePageViewController *home=[[HomePageViewController alloc]init];
    home.tabBarItem.image = [[UIImage imageNamed:@"tab_home_icon_n"]imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal];
    home.tabBarItem.selectedImage = [[UIImage imageNamed:@"tab_home_icon_s"]imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal];
    home.title=@"首页";
    
    ClassifyViewController *classfiy=[[ClassifyViewController alloc]init];
    classfiy.tabBarItem.image = [[UIImage imageNamed:@"tab_winner_icon_n"]imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal];
    classfiy.tabBarItem.selectedImage = [[UIImage imageNamed:@"tab_winner_icon_s"]imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal];
    classfiy.title=@"分类";
    
    BusinessCenterViewController *center=[[BusinessCenterViewController alloc]init];
    center.title=@"商家中心";
    center.tabBarItem.image = [[UIImage imageNamed:@"tab_gwc_icon_n"]imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal];
    center.tabBarItem.selectedImage = [[UIImage imageNamed:@"tab_gwc_icon_s"]imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal];
    
    FindViewController *find=[[FindViewController alloc]init];
    find.title=@"发现";
    find.tabBarItem.image = [[UIImage imageNamed:@"tab_my_icon_n"]imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal];
    find.tabBarItem.selectedImage = [[UIImage imageNamed:@"tab_my_icon_s"]imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal];
    
    PersonalViewController *mine=[[PersonalViewController alloc]init];
    mine.title=@"我的";
    mine.tabBarItem.image = [[UIImage imageNamed:@"tab_my_icon_n"]imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal];
    mine.tabBarItem.selectedImage = [[UIImage imageNamed:@"tab_my_icon_s"]imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal];
    
    
    BasicNavigationController *firstnav=[[BasicNavigationController alloc]initWithRootViewController:home];
    BasicNavigationController *secdnav=[[BasicNavigationController alloc]initWithRootViewController:classfiy];
    BasicNavigationController *thirdnav=[[BasicNavigationController alloc]initWithRootViewController:center];
    BasicNavigationController *fournav=[[BasicNavigationController alloc]initWithRootViewController:find];
    BasicNavigationController *fivenav=[[BasicNavigationController alloc]initWithRootViewController:mine];
    self.viewControllers=@[firstnav,secdnav,thirdnav,fournav,fivenav];
    
}

@end
